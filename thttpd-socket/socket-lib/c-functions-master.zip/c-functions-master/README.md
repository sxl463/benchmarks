c-functions
===========

A variety of functions for C
